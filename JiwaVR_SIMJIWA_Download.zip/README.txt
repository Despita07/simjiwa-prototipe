JIWAVR — PROTOTIPE LABORATORIUM VIRTUAL KEPERAWATAN JIWA
Versi demo 1.0

ISI PAKET
- index.html : prototipe web interaktif satu file, tanpa instalasi dan tanpa library eksternal.
- README.txt : petunjuk penggunaan dan publikasi.

FITUR DEMO
- Beranda dengan ilustrasi ruang konsultasi virtual.
- Galeri lima stasiun pembelajaran.
- Simulasi kasus fiktif “Suara yang Mengganggu” dengan pilihan respons dan umpan balik.
- Tahap latihan pengkajian keselamatan.
- Jiwa-AI mode demo berbasis aturan/kata kunci (belum terhubung ke model GenAI).
- Refleksi dan checklist keterampilan; refleksi dapat diunduh menjadi .txt.
- Desain responsif untuk laptop dan ponsel.

CARA MENJALANKAN PALING MUDAH
1. Ekstrak file ZIP.
2. Buka folder JiwaVR_Prototipe.
3. Klik dua kali index.html.
4. File akan terbuka di browser. Koneksi internet tidak diperlukan untuk demo lokal.

CARA MEMPUBLIKASIKAN MELALUI GITHUB PAGES
1. Masuk ke GitHub dan buka repository prototipe Anda.
2. Unggah index.html ke folder utama repository (root). Bila sudah ada index.html lama, unduh/cadangkan dahulu lalu ganti dengan file ini.
3. Klik Commit changes.
4. Buka Settings > Pages.
5. Pada Build and deployment, pilih Deploy from a branch.
6. Pilih branch main dan folder /(root), lalu Save.
7. Tunggu proses publikasi, kemudian buka URL yang ditampilkan di bagian Pages.

Jika menggunakan Vercel, unggah folder berisi index.html sebagai proyek static. Tidak perlu API untuk versi demo ini.

CATATAN PENTING
- Ini prototipe pendidikan, bukan perangkat klinis dan bukan aplikasi VR headset native.
- Visual ruang konsultasi adalah ilustrasi 2D bergaya ruang virtual; belum berupa lingkungan 3D penuh yang bisa dijelajahi dengan headset.
- Jiwa-AI pada versi ini menggunakan aturan lokal dan tidak mengirim pesan ke layanan AI.
- Untuk GenAI sungguhan, buat backend server/API terpisah dan simpan API key sebagai environment variable di server. Jangan pernah memasukkan API key ke index.html atau repository publik.
- Kasus harus tetap fiktif. Jangan masukkan data pasien yang dapat diidentifikasi.
- Sebelum dipakai dalam perkuliahan, minta dosen keperawatan jiwa memvalidasi materi terhadap SDKI, SLKI, SIKI, SOP institusi, dan pedoman klinis yang berlaku.
